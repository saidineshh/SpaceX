import { Component, OnInit } from '@angular/core';
import { SpacexdataService } from '../services/spacexdata.service'

@Component({
  selector: 'app-launch-programs',
  templateUrl: './launch-programs.component.html',
  styleUrls: ['./launch-programs.component.scss']
})
export class LaunchProgramsComponent implements OnInit {

  years = [2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020];
  dataSource: any;
  yearValue: number = null;
  launch: boolean = true;
  landing: boolean = true;
  constructor(private spacexservice: SpacexdataService) { }

  ngOnInit(): void {
    this.spacexservice.getAllData().subscribe(response => {
      this.dataSource = response;
    });
  }

  getData() {
    this.spacexservice.getFilterData(this.yearValue, this.launch, this.landing).subscribe(response => {
      this.dataSource = response;
    });
  }

}
