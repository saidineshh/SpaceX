import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SpacexdataService {

  constructor(private http: HttpClient) { }

  getAllData(): Observable<any> {
    return this.http.get(`https://api.spaceXdata.com/v3/launches?limit=100`);
  }

  getFilterData(year, launch, landing): Observable<any> {
    return this.http.get(`https://api.spaceXdata.com/v3/launches?limit=100` + '&launch_success=' + launch + '&land_success=' + landing + '&launch_year=' + year);
  }
}
